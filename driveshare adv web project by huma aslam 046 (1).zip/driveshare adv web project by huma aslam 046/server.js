require('dotenv').config();
const express = require('express');
const path = require('path');
const session = require('express-session'); // 🎯 1. IMPORT SESSION MANAGER
const connectDB = require('./config/db');
const webRoutes = require('./routes/webRoutes'); 

const app = express();

// Connect to MongoDB Compass
connectDB();

// Setup View Engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middlewares
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

// 🎯 2. INITIALIZE STATEFUL STATE COOKIE ENGINE
app.use(session({
    secret: process.env.SESSION_SECRET || 'driveshare_elite_secret_key_99x',
    resave: false,
    saveUninitialized: false,
    cookie: { 
        maxAge: 1000 * 60 * 60 * 24 // Cookie stays active for 24 hours
    }
}));

// Use the web routes cleanly map
app.use('/', webRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Production-Grade System Operational: http://localhost:${PORT}`));