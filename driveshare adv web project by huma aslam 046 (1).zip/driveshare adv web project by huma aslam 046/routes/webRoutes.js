const express = require('express');
const router = express.Router();
const pageCtrl = require('../controllers/pageController');

// 🛡️ IMPORT SECURITY INTERCEPTOR MIDDLEWARE
const protectAdmin = require('../Middleware/authMiddleware');

//  Landing Page Route
router.get('/', pageCtrl.getHome);

//  Showroom Fleet Routes
router.get('/showroom', pageCtrl.getShowroom);
router.post('/showroom/book', pageCtrl.postBookCar);

//  Corporate Contact Routes
router.get('/contact', pageCtrl.getContact);
router.post('/contact', pageCtrl.postInquiry);

// ==========================================================================
// 🔒 ADMIN OPERATIONS ROUTE CHANNELING MATRIX
// ==========================================================================
const adminCtrl = require('../controllers/adminController');

// Authentication Entry Gates
router.get('/admin/login', adminCtrl.getLogin);
router.post('/admin/login', adminCtrl.postLogin);

// Dynamic Profile Registry (Signup Channels)
router.get('/admin/signup', adminCtrl.getSignup);
router.post('/admin/signup', adminCtrl.postSignup);

// 🎯 SECURED ROUTE: Intercepted by security guard middleware before rendering dashboard
router.get('/admin/dashboard', protectAdmin, adminCtrl.getDashboard);

// Logout Terminal
router.get('/admin/logout', adminCtrl.getLogout);

module.exports = router;