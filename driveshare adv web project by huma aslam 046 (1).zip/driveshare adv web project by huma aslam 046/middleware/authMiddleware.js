module.exports = (req, res, next) => {
    // Check if the operator session contains valid admin credentials
    if (req.session && req.session.isAdmin) {
        return next(); // Session valid. Pass execution control to the next node!
    }
    
    // Unauthorized access attempt. Force redirect to gateway checkpoint.
    console.warn("🔒 Security Guard: Unauthorized access intercepted. Routing to gateway...");
    return res.redirect('/admin/login');
};