const mongoose = require('mongoose');

const VehicleSchema = new mongoose.Schema({
    make: { type: String, required: true },
    model: { type: String, required: true },
    year: { type: Number, required: true },
    pricePerDay: { type: Number, required: true },
    image: { type: String, default: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=500' },
    available: { type: Boolean, default: true }
});

module.exports = mongoose.model('Vehicle', VehicleSchema);