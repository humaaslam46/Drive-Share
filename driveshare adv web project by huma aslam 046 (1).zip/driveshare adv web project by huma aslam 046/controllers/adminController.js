const Booking = require('../models/Booking');
const Inquiry = require('../models/Inquiry');
const Admin = require('../models/Admin');

exports.getLogin = async (req, res) => {
    if (req.session && req.session.isAdmin && req.query.logout !== 'true') {
        return res.redirect('/admin/dashboard');
    }

    try {
        if (req.query.logout === 'true') {
            return res.render('admin-login', { error: 'Session safely terminated. Node disconnected.' });
        }

        const defaultAdmin = await Admin.findOne({});
        if (defaultAdmin) {
            console.log(`Auto-Login Engine: Found registered profile [${defaultAdmin.username}].`);
            req.session.isAdmin = true;
            req.session.user = { username: defaultAdmin.username, role: defaultAdmin.role };
            return res.redirect('/admin/dashboard');
        }

        return res.redirect('/admin/signup');
    } catch (err) {
        console.error("Login Error:", err);
        res.render('admin-login', { error: 'Failed to negotiate authentication nodes.' });
    }
};

// Completely destroy the session on logout and pass the logout flag
exports.getLogout = (req, res) => {
    if (req.session) {

        req.session.destroy((err) => {
            if (err) {
                console.error("Failed to destroy session:", err);
                return res.redirect('/admin/dashboard');
            }
            // Clear the browser session cookie completely
            res.clearCookie('connect.sid'); 
            // Redirect to login with a special parameter telling it NOT to auto-login
            return res.redirect('/admin/login?logout=true');
        });
    } else {
        res.redirect('/admin/login');
    }
};

// Process Manual Login Form Credentials (Fallback)
exports.postLogin = async (req, res) => {
    const { username, password } = req.body;
    
    try {
        // Query explicitly by passing the form values
        const foundAdmin = await Admin.findOne({ username: username.trim(), password: password });
        if (foundAdmin) {
            req.session.isAdmin = true;
            req.session.user = { username: foundAdmin.username, role: foundAdmin.role };
            return res.redirect('/admin/dashboard');
        } else {
            return res.render('admin-login', { error: 'Invalid System Record Verification Credentials.' });
        }
    } catch (err) {
        console.error("Post Login Error:", err);
        res.render('admin-login', { error: 'Database handshake error.' });
    }
};

// Serve Signup Registration Configuration UI
exports.getSignup = (req, res) => {
    res.render('admin-signup', { error: null });
};

// Handle Saving New Administrators to MongoDB cleanly
exports.postSignup = async (req, res) => {
    const { username, password } = req.body;

    try {
        if (!username || !password) {
            return res.render('admin-signup', { error: 'Operator ID and Security Key are required.' });
        }

        const existingAdmin = await Admin.findOne({ username: username.trim() });
        if (existingAdmin) {
            return res.render('admin-signup', { error: 'Operator ID already active in the network grid.' });
        }

        // Explicitly await the database creation write lifecycle completely!
        const newAdmin = await Admin.create({ 
            username: username.trim(), 
            password: password 
        });
        
        // Save state parameters cleanly to session memory
        req.session.isAdmin = true;
        req.session.user = { username: newAdmin.username, role: newAdmin.role };
        
        res.redirect('/admin/dashboard');
    } catch (err) {
        console.error("Signup Write Error:", err);
        res.render('admin-signup', { error: 'Failed to write account records to database.' });
    }
};

// Gather Live Telemetry Logs & Serve Admin Dashboard 
exports.getDashboard = async (req, res) => {
    if (!req.session || !req.session.isAdmin) {
        return res.redirect('/admin/login');
    }

    try {
        const bookings = await Booking.find({}).sort({ bookedAt: -1 });
        const inquiries = await Inquiry.find({}).sort({ createdAt: -1 });

        res.render('admin', { bookings, inquiries });
    } catch (err) {
        console.error("Dashboard Load Error:", err);
        res.status(500).send('System Registry Query Operational Failure.');
    }
};