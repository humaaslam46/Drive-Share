const Vehicle = require('../models/Vehicle');
const Inquiry = require('../models/Inquiry');

exports.getHome = async (req, res) => {
    const cars = await Vehicle.find({ available: true });
    res.render('index', { cars, user: req.session.user || null });
};

exports.getContact = (req, res) => {
    res.render('contact', { user: req.session.user || null, success: false });
};

exports.postContact = async (req, res) => {
    const { name, email, message } = req.body;
    await Inquiry.create({ name, email, message });
    res.render('contact', { user: req.session.user || null, success: true });
};