const Vehicle = require('../models/Vehicle');
const Booking = require('../models/Booking');
const Inquiry = require('../models/Inquiry');

// Page 1: Premium Landing Page
exports.getHome = async (req, res) => {
    res.render('index');
};

// Page 2: Showroom (Fetched from MongoDB)
exports.getShowroom = async (req, res) => {
    const cars = await Vehicle.find({ available: true });
    res.render('showroom', { cars });
};

// Handle Car Rental Form Submission
exports.postBookCar = async (req, res) => {
    const { carId, carName, customerName, contactNumber, address } = req.body;
    await Booking.create({ carId, carName, customerName, contactNumber, address });
    res.redirect('/showroom?success=true');
};

// Page 3: General Contact Form
exports.getContact = (req, res) => {
    res.render('contact', { success: false });
};

exports.postInquiry = async (req, res) => {
    const { name, email, message } = req.body;
    await Inquiry.create({ name, email, message });
    res.render('contact', { success: true });
};